    //Start

    var suspectsArray = ["Mr. Green", "Colonel Mustard", "Ms. Peacock", "Ms. Scarlet", "Professor Plum", "Doctor Orchid"]
    var weaponsArray = ["Candlestick", "Revolver", "Dagger", "Metal Pipe", "Wrench", "Rope", "Plunger", "Statue"]
    var roomsArray = ["The Ballroom", "The Conservatory", "The Bedroom", "The Kitchen", "The Billards Room", "The Dining Room", "The Garden", "The Bathroom", "The Study", "The Labotory"]
   
    //Shuffling The Arrays
    shuffleArray(suspectsArray)
    shuffleArray(weaponsArray)
    shuffleArray(roomsArray)
   
    //Storing the mystery object
    var finalAnswer = pickMystery();
    
    //Functions

    //Creating the mystery object by calling for indivusal items from each Array
    function pickMystery()
    {
    var finalSuspect = selectRandom(suspectsArray)
    var finalWeapon = selectRandom(weaponsArray)
    var finalRoom = selectRandom(roomsArray)
    let mystery = {
        name: finalSuspect,
        weapon: finalWeapon,
        room: finalRoom
    }
    console.log(mystery)
    return mystery;
    }

    //Selecting the item from each array for the mystery object
    function selectRandom(pickedArray)
    {
        var index = Math.floor(Math.random() * pickedArray.length)
        var answer = pickedArray[index]
        pickedArray.splice(index, 1)
        return answer
    }

    //Drawing a random card from one of the three arrays at random
    function selectCard() {
        var decide = Math.floor(Math.random() * 3)
        if (decide % 3 === 0)
        {
            var index = Math.floor(Math.random() * suspectsArray.length)
            var answer = suspectsArray[index]
            suspectsArray.splice(index, 1)
            window.alert(answer)
        }
        if (decide % 3 === 1)
        {
            var index = Math.floor(Math.random() * weaponsArray.length)
            var answer = weaponsArray[index]
            weaponsArray.splice(index, 1)
            window.alert(answer)
        }
        if (decide % 3 === 2)
        {
            var index = Math.floor(Math.random() * roomsArray.length)
            var answer = roomsArray[index]
            roomsArray.splice(index, 1)
            window.alert(answer)
        }
    }

    //Reveals the mystery object
    function revealMystery()
    {
        window.alert(finalAnswer.name + " killed Mr. Marist using the " + finalAnswer.weapon + " in the " + finalAnswer.room + "!")
    }
    
    //Changes the color of the button depend on if it's been clicked or not
    function setColor(buttonId) {
        var button = document.getElementById(buttonId);
        const buttonStyle = window.getComputedStyle(button);
        const backgroundColor = buttonStyle.getPropertyValue("background-color");
        function rgbToHex(rgb) {
            rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
            return "#" + rgb.slice(1).map(color => {
                const hex = parseInt(color).toString(16);
                return hex.length === 1 ? "0" + hex : hex;
            }).join("");
        }
        var check = rgbToHex(backgroundColor);
        if (check === "#d9c0a1") {
            button.style.backgroundColor = "#d82828";
        } else if (check === "#d82828") {
            button.style.backgroundColor = "" 
        }
                                }

    //Shuffles the array
    function shuffleArray(array) {
    for (var i = array.length - 1; i >= 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}